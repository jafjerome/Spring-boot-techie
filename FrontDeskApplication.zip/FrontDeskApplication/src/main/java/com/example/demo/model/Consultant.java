package com.example.demo.model;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement(name = "item")
public class Consultant {
	private int id;
	private String type;
	private String name;
	private String avaliableDay;
	private String avaliableTime;
	private String isAvaliable;
	private int hospitalid;
}
