package com.example.demo.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement(name = "list")
public class Item {
	private List<Consultant> item;
}
