package com.example.demo.Exception;

import java.time.ZonedDateTime;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
@XmlRootElement
public class APIException {
private final String message;
private final HttpStatus httpStatus;
private final ZonedDateTime timestamp;
}
