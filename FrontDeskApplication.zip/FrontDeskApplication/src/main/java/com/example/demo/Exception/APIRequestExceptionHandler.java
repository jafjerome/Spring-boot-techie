package com.example.demo.Exception;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class APIRequestExceptionHandler {
	@ExceptionHandler(value = { APIRequestException.class })
	public ResponseEntity<Object> handleAPIRequestException(APIRequestException e) {
		HttpStatus badrequest = HttpStatus.BAD_REQUEST;
		APIException apiException = new APIException(e.getMessage(), badrequest, ZonedDateTime.now(ZoneId.of("Asia/Kolkata")));
		return new ResponseEntity<>(apiException, badrequest);
	}
}
