package com.example.demo.constants;

public final class FrontDeskConstants {
	private FrontDeskConstants() {
	}

	public static final String REQUIREMENTURL = "http://localhost:8080/SpecialistDetails?HospitalName=SIMS&SpecialistType=Dentist";
	public static final String INVALIDHOS = "Invalid Input For Hospital Name";
	public static final String NOBED = "Beds Are Not Avaliable For Admission";
	public static final String NOREC = "You Have Entered is not Found our the Records Please Renter the correct Hospital Name";
	public static final String BED = "Number of Avaliable Beds : ";
	public static final String NOAPPOINTMENT = "Appointment slot is unavaliable for the specialist : ";
	public static final String NOSPECIALIST = "No Specialist details found for the given hospital name : ";
}
