package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Appointment;
import com.example.demo.model.Consultant;

public interface FrontDeskService {
	public List<Consultant> getSpecialList(String HospitalName, String SpecialistType);

	public Appointment bookAppointment(String SpecialistName, String AppintmentDay, String PatientName);

	public int getTotalNumberOfAvaliableBeds(String HospitalName);

}
