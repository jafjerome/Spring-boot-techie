package com.example.demo.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class Hospital {
	private int HospitalId;
	private String HospitalName;
	private int TotalBedCount;
	private List<Patient> patient;
	private List<Consultant> consultant;
}
