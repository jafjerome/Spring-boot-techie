package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Exception.APIRequestException;
import com.example.demo.constants.FrontDeskConstants;
import com.example.demo.impl.FrontDeskServiceImpl;
import com.example.demo.model.Appointment;
import com.example.demo.model.Consultant;
import com.example.demo.model.Item;

@RestController
public class Frontdeskcontroller {

	private final static Logger log = LoggerFactory.getLogger(Frontdeskcontroller.class);

	@Autowired
	FrontDeskServiceImpl frontDeskService;

	@GetMapping("/SpecialistDetails")
	public Item getSpecialistList(@RequestParam String HospitalName, @RequestParam String SpecialistType) {
		log.info("Inside getSpecialistList");
		Item item = new Item();
		if (HospitalName == "null" || HospitalName.isEmpty() || HospitalName == "") {
			throw new APIRequestException(FrontDeskConstants.INVALIDHOS);
		} else {
			List<Consultant> consultantList = frontDeskService.getSpecialList(HospitalName, SpecialistType);
			if (consultantList.size() <= 0) {
				throw new APIRequestException(FrontDeskConstants.NOSPECIALIST + SpecialistType);
			} else {
				item.setItem(consultantList);
			}
		}
		return item;
	}

	@PostMapping(value="/bookAppointment")
	public Appointment bookAppointment(@RequestParam String specialistName, @RequestParam String appointmentDay,
			@RequestParam String PatientName) {
		Appointment appointment = frontDeskService.bookAppointment(specialistName, appointmentDay, PatientName);
		if (appointment.getSpecialistname() == null) {
			throw new APIRequestException(FrontDeskConstants.NOAPPOINTMENT + specialistName + " on " + appointmentDay);
		}
		return appointment;
	}

	@GetMapping("/bedcounts")
	public String getNumberOfAvaliableBeds(@RequestParam String HospitalName) {
		if (HospitalName == "null" || HospitalName.isEmpty() || HospitalName == "") {
			throw new APIRequestException(FrontDeskConstants.INVALIDHOS);
		}
		int count = frontDeskService.getTotalNumberOfAvaliableBeds(HospitalName);
		if (count == 0) {
			throw new APIRequestException(FrontDeskConstants.NOBED);
		} else if (count == -1) {
			throw new APIRequestException("Hospital Name : " + HospitalName+" "+ FrontDeskConstants.NOREC);
		}
		return FrontDeskConstants.BED + count;
	}
}
