package com.example.demo.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Consultant;
import com.example.demo.model.Hospital;
import com.example.demo.model.Patient;
import com.example.demo.service.FrontDeskService;

@Service
public class FrontDeskServiceImpl implements FrontDeskService {

	List<Hospital> HospitalList = new ArrayList<Hospital>();

	public List<Hospital> buliderData() {
		List<Hospital> hospitalList = new ArrayList<Hospital>();
		List<Consultant> consultantList = null;
		List<Patient> patientlist = new ArrayList<Patient>();

		Hospital hos = new Hospital();
		hos.setHospitalId(946);
		hos.setHospitalName("SIMS");
		hos.setTotalBedCount(12);

		Patient pat = new Patient();
		pat.setName("Jafrin");
		pat.setAddress("Tiruppur");
		pat.setStatus("ADMITTED");
		patientlist.add(pat);

		pat = new Patient();
		pat.setName("John");
		pat.setAddress("Coimbatore");
		pat.setStatus("ADMITTED");
		patientlist.add(pat);

		// adding patpatientlist to the hospital
		hos.setPatient(patientlist);

		consultantList = new ArrayList<Consultant>();
		Consultant consultant = new Consultant();
		consultant.setId(112);
		consultant.setType("Dentist");
		consultant.setName("Angela");
		consultant.setAvaliableDay("Monday,Saturday");
		consultant.setAvaliableTime("4 to 7 PM");
		consultant.setIsAvaliable("N");
		consultantList.add(consultant);

		Consultant consultant1 = new Consultant();
		consultant1.setId(113);
		consultant1.setType("General");
		consultant1.setName("Kannan");
		consultant1.setAvaliableDay("Monday,Saturday");
		consultant1.setAvaliableTime("6 to 7 PM");
		consultant1.setIsAvaliable("Y");
		consultantList.add(consultant1);

		Consultant consultant2 = new Consultant();
		consultant2.setId(113);
		consultant2.setType("Dentist");
		consultant2.setName("Megala");
		consultant2.setAvaliableDay("Monday,Saturday");
		consultant2.setAvaliableTime("6 to 9 PM");
		consultant2.setIsAvaliable("Y");
		consultantList.add(consultant2);

		// Adding Consultant List to hospital
		hos.setConsultant(consultantList);

		// Creating another Set
		Hospital hos1 = new Hospital();
		patientlist = new ArrayList<Patient>();
		hos1.setHospitalId(947);
		hos1.setHospitalName("Apollo");
		hos1.setTotalBedCount(25);

		Patient pat1 = new Patient();
		pat1.setName("David");
		pat1.setAddress("Coimbatore");
		pat1.setStatus("DISCHARGE");
		patientlist.add(pat1);

		pat1 = new Patient();
		pat1.setName("Jerome");
		pat1.setAddress("Chennai");
		pat1.setStatus("ADMITTED");
		patientlist.add(pat1);

		// adding patpatientlist to the hospital
		hos1.setPatient(patientlist);

		consultantList = new ArrayList<Consultant>();
		Consultant cconsultant = new Consultant();
		cconsultant.setId(212);
		cconsultant.setType("Ortho");
		cconsultant.setName("Sofia");
		cconsultant.setAvaliableDay("Monday,Saturday");
		cconsultant.setAvaliableTime("4 to 7 PM");
		cconsultant.setIsAvaliable("N");
		consultantList.add(cconsultant);

		Consultant cconsultant1 = new Consultant();
		cconsultant1.setId(213);
		cconsultant1.setType("General");
		cconsultant1.setName("Bala");
		cconsultant1.setAvaliableDay("Monday,Saturday");
		cconsultant1.setAvaliableTime("6 to 7 PM");
		cconsultant1.setIsAvaliable("Y");
		consultantList.add(cconsultant1);

		Consultant cconsultant2 = new Consultant();
		cconsultant2.setId(113);
		cconsultant2.setType("Ortho");
		cconsultant2.setName("Perumal");
		cconsultant2.setAvaliableDay("Monday,Saturday");
		cconsultant2.setAvaliableTime("6 to 10 PM");
		cconsultant2.setIsAvaliable("Y");
		consultantList.add(cconsultant2);

		// Adding Consultant List to hospital
		hos1.setConsultant(consultantList);

		// Adding two Hospital Objects to Hospitalist
		hospitalList.add(hos1);
		hospitalList.add(hos);

		return hospitalList;
	}

	@Cacheable(value = "ten-second-cache", key = "'Specilaist'")
	public List<Consultant> getSpecialList(String HospitalName, String SpecialistType) {
		List<Hospital> HospitalList = buliderData();
		// TODO Auto-generated method stub System.out.println("Inside");
		List<Consultant> consultantList = new ArrayList<Consultant>();
		HospitalList.forEach(hospital -> {
			hospital.getConsultant().forEach(cosultant -> {
				if (cosultant.getType().equalsIgnoreCase(SpecialistType)) {
					cosultant.setHospitalid(hospital.getHospitalId());
					consultantList.add(cosultant);
				}
			});
		});

		return consultantList;
	}

	@Override
	public Appointment bookAppointment(String SpecialistName, String AppointmentDay, String PatientName) {
		// TODO Auto-generated method stub
		List<Hospital> HospitalList = buliderData();
		Appointment app = new Appointment();
		HospitalList.forEach(hospital -> {
			hospital.getConsultant().forEach(consultant -> {
				if (consultant.getName().equalsIgnoreCase(SpecialistName) && consultant.getIsAvaliable() == "Y"
						&& consultant.getAvaliableDay().contains(AppointmentDay)) {
					app.setAppointmentDay(AppointmentDay);
					app.setAppointmentTime(consultant.getAvaliableTime());
					app.setPatientname(PatientName);
					app.setSpecialistname(SpecialistName);
				}
			});
		});
		return app;
	}

	@Override
	public int getTotalNumberOfAvaliableBeds(String HospitalName) {
		// TODO Auto-generated method stub
		List<Hospital> HospitalList = buliderData();
		int avaliablebeds = 0;
		int flag=0;
		for (Hospital hospital : HospitalList) {
			if (hospital.getHospitalName().equalsIgnoreCase(HospitalName)) {
				flag=1;
				break;
			}
			else {
				flag=2;
			}
		}
		for (Hospital hospital : HospitalList) {
			if (hospital.getHospitalName().equalsIgnoreCase(HospitalName)) {
				avaliablebeds = hospital.getTotalBedCount();
				System.out.println(avaliablebeds);
				for (Patient patients : hospital.getPatient()) {
					avaliablebeds = patients.getStatus().equals("ADMITTED") ? avaliablebeds - 1 : avaliablebeds;
				}
			}
		}
		avaliablebeds=flag==2?-1:avaliablebeds;
		return avaliablebeds;
	}
}
