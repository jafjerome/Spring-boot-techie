package com.example.demo.model;

import lombok.Data;

@Data
public class Patient {
	private String name;
	private String address;
	private String status;
}
