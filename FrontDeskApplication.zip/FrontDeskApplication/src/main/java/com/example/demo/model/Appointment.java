package com.example.demo.model;

import lombok.Data;

@Data
public class Appointment {
	private String Specialistname;
	private String AppointmentDay;
	private String Patientname;
	private String AppointmentTime;

}
