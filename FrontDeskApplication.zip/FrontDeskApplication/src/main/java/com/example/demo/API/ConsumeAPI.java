package com.example.demo.API;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.constants.FrontDeskConstants;
import com.example.demo.model.Consultant;

@Component
public class ConsumeAPI implements CommandLineRunner {

	private static void callServiceJSON() {
		Logger log = LoggerFactory.getLogger(ConsumeAPI.class);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> response = new RestTemplate().exchange(FrontDeskConstants.REQUIREMENTURL,HttpMethod.GET, entity, String.class);
		String cons = response.getBody();
		log.info("***************JSON RESPONSE***************");
		log.info(" "+cons);
	}
	private static void callServiceXML() {
		Logger log = LoggerFactory.getLogger(ConsumeAPI.class);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(new MediaType[] {MediaType.APPLICATION_XML}));
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> response = new RestTemplate().exchange(FrontDeskConstants.REQUIREMENTURL,HttpMethod.GET, entity, String.class);
		String cons = response.getBody();
		log.info("***************XML RESPONSE***************");
		log.info(" "+cons);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		callServiceXML();
		callServiceJSON();
	}

}
