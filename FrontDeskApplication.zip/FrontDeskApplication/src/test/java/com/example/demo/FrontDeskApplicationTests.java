package com.example.demo;

import static org.hamcrest.CoreMatchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.service.FrontDeskService;

@SpringBootTest
@AutoConfigureMockMvc
class FrontDeskApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FrontDeskService service;

	@Test
	public void shouldReturnDefaultMessage() throws Exception {
		this.mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("Hello, World")));
	}

	/*
	 * @Test public Item getSpecialistList() throws Exception {
	 * 
	 * when(service.getSpecialList("SIMS", "Dentist")).thenReturn(List<Consultant>);
	 * this.mockMvc.perform(get("/SpecialistDetails/{HospitalName}/{SpecialistType}"
	 * )).andDo(print()).andExpect(status().isOk());
	 * //.andExpect(content().string(containsString("Hello, Mock"))); }
	 */

}
