package com.example.demo;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Constants.APIConstants;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class RestApiApplicationTests {

	@Test
	public void givenDataIsJson_whenDataIsPostedByPostForObject_thenResponseBodyIsNotNull()
	  throws IOException {
		 ObjectMapper objectMapper = new ObjectMapper();
		JSONObject personJsonObject = new JSONObject();
		JSONObject personJsonObject1 = new JSONObject();
		personJsonObject.put("count", 6);
		personJsonObject1.put("output", personJsonObject);
		HttpHeaders headers1 = new HttpHeaders();
		headers1.setContentType(MediaType.APPLICATION_JSON);
		headers1.set("UserID", "xVkVFayg2");
	    HttpEntity<String> request = 
	      new HttpEntity<String>(personJsonObject1.toString(), headers1);
	    
	    String personResultAsJsonStr = new RestTemplate().postForObject(APIConstants.POSTURL, request, String.class);
	    JsonNode root = objectMapper.readTree(personResultAsJsonStr);
	    
	    assertNotNull(personResultAsJsonStr);
	    assertNotNull(root);
	    //assertNotNull(root.path("name").asText());
	}

}
