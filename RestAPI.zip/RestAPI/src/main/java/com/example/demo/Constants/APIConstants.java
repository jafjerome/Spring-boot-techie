package com.example.demo.Constants;

public final class APIConstants {
	private APIConstants() {
	}
	public static final String USERID="xVkVFayg2";
	public static final String CHA = "https://http-hunt.thoughtworks-labs.net/challenge/input";
	public static final String GETURL = "https://http-hunt.thoughtworks-labs.net/challenge/input";
	public static final String POSTURL = "https://http-hunt.thoughtworks-labs.net/challenge/output";
}
