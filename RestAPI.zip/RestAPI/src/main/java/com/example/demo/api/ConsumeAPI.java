package com.example.demo.api;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Constants.APIConstants;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class ConsumeAPI implements CommandLineRunner {
	WebTarget target;
	Client client;

	private static void callGETServiceJSON() throws IOException, JsonProcessingException, ParseException {
		JSONObject ansObject = new JSONObject();
		JSONObject ansObject1 = new JSONObject();
		int count = 0;
		int money=0;
		Logger log = LoggerFactory.getLogger(ConsumeAPI.class);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("UserID", "xVkVFayg2");
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ArrayList <String>catdetails = new ArrayList<String>();
		ResponseEntity<String> response = new RestTemplate().exchange(APIConstants.CHA, HttpMethod.GET, entity,
				String.class);
		String root = response.getBody();
		log.info("***************Response call Started ***************");
		log.info(root);
		/*
		 * Date now = new Date(); for (Category cat : root) { Date startdate = new
		 * SimpleDateFormat("yyyy-MM-dd").parse(cat.getStartDate()); if
		 * (cat.getEndDate() != null) { Date dateEnd = new
		 * SimpleDateFormat("yyyy-MM-dd").parse(cat.getEndDate()); Date dateStart = new
		 * SimpleDateFormat("yyyy-MM-dd").parse(cat.getStartDate()); if
		 * ((dateEnd.compareTo(now) > 0) && (dateStart.compareTo(now) < 0 ||
		 * dateStart.compareTo(now) == 0)) { count++; money=cat.getPrice()+money;
		 * //catdetails.add(cat.getCategory()); } } else { if (startdate.compareTo(now)
		 * < 0 || startdate.compareTo(now) == 0 ) { count++; money=cat.getPrice()+money;
		 * //catdetails.add(cat.getCategory()); } }
		 */
		}
		/*
		 * Set<String> distinct = new HashSet<>(catdetails); for (String s: distinct) {
		 * System.out.println(s + ": " + Collections.frequency(catdetails, s));
		 * ansObject.put(s, Collections.frequency(catdetails, s)); }
		 * Stream.of(catdetails.toString()) .forEach(System.out::println);
		 */
		
		/*
		 * System.out.println(money); ansObject.put("totalValue", money);
		 * ansObject1.put("output", ansObject); System.out.println("JSON :" +
		 * ansObject1); HttpEntity<String> entity1 = new
		 * HttpEntity<String>(ansObject1.toJSONString(), headers); //String response1 =
		 * new RestTemplate().postForObject(APIConstants.POSTURL, entity1,
		 * String.class); log.info("Ended");
		 */
	

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		callGETServiceJSON();
		// callPOSTServiceJSON();
	}

}
