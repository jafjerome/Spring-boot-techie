package com.example.demo.api;

import lombok.Data;

@Data
public class Category 
{
private String name;
private String category;
private int price;
private String startDate;
private String endDate;
}
